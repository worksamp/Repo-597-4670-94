import {Component} from 'angular2/core';

@Component({
  selector: 'users-home',
  templateUrl: './components/users/users_home/users_home.html'
})
export class UsersHomeCmp {}
