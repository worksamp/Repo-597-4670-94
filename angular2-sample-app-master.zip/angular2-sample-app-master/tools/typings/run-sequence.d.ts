declare module 'run-sequence' {
  function runSequence(...args: any[]): void;
  module runSequence {}
  export = runSequence;
}
