declare module 'slash' {
  function slash(path: string): string;
  module slash {}
  export = slash;
}
